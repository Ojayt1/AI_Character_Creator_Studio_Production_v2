# Production Architecture

## 1. Character schema
A character is a structured document, not a flattened image.

```text
Project
 ├─ style
 ├─ demographics
 ├─ selected assets
 ├─ expression
 ├─ hand
 ├─ pose
 ├─ views
 └─ rig
     ├─ layer IDs
     ├─ parent IDs
     ├─ pivots
     ├─ z-order
     └─ export metadata
```

## 2. Asset library contract
Every production asset should be delivered with:
- stable ID
- style ID
- compatible body types
- compatible age/gender tags
- supported views
- SVG source
- pivot
- bounding box
- z-order
- optional rig/bone metadata

## 3. AI pipeline
User brief -> AI structured JSON -> validation -> compatible asset selection -> character assembly -> six-view consistency check -> rig export.

The AI must produce structured parameters/assets rather than an uncontrolled flattened illustration.

## 4. Animation pipeline
Moho:
- stable SVG layer names
- pivots
- parent relationships
- z-order
- optional bone metadata

After Effects:
- same stable layer IDs
- separate SVG/PNG assets
- import manifest
- pivot coordinates

## 5. SaaS production layer
Next production increment:
- accounts
- cloud projects
- version history
- asset marketplace/library
- team workspaces
- usage metering
- subscription/billing
- server-side AI generation
- background asset processing
- export jobs
