# Product Specification

## Stable layer IDs
Head, Hair, Eyebrows, Eyes, Nose, Mouth, Ears, Beard, Neck, Torso, Left Arm, Right Arm, Hands, Legs, Shoes, Accessories.

## Project schema
A project is JSON and contains style, demographic attributes, selected asset variants, expression, hand, pose, current view, zoom and layer visibility.

## Export contract
SVG: one SVG with named groups and `data-rig-layer` metadata.
PSD: one Photoshop layer per stable layer ID.
Rig Pack: six view folders, each containing a composite SVG and each individual layer SVG, plus project JSON and manifest.

## Moho / After Effects compatibility
The stable layer IDs and separated SVG files are intentionally designed so the next production stage can add:
- anchor/pivot coordinates
- bone parent IDs
- z-order
- deformation metadata
- Moho layer naming
- After Effects import naming
without changing the UI.
