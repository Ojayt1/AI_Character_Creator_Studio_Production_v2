# AI Character Creator Studio — v1

This is a production-oriented, asset-driven web application rather than a visual mockup.

## Core product behavior
- Character parameters are stored as structured project data.
- The character is composed from named SVG rig layers.
- Six directional views are available.
- Style, gender, age, body, skin, hair, face, beard, clothing and accessory selections update the generated character.
- Expressions, hands and poses are separate selectable systems.
- Layer visibility and layer selection are available.
- Undo/redo, local save and project JSON are supported.
- SVG, PNG, JPEG, layered PSD and rig-pack ZIP exports are supported.
- Rig Pack contains every view plus individual SVGs for every named layer and a manifest.

## Run
Serve this directory over HTTP:
`python -m http.server 8080`
Then open `http://localhost:8080`.

The PSD and Rig Pack exporters use ag-psd and JSZip from jsDelivr. For an offline commercial deployment, vendor those libraries into `vendor/`.

## Commercial production roadmap
Replace the procedural vector asset registry with commissioned/owned SVG asset packs while preserving the same layer IDs and project schema. This allows artists to build a much larger library without changing the application architecture.
