# AI Character Creator Studio — Production v2

This release advances the v1 editor into a production-oriented character authoring system.

## Product features
- Structured character project state
- Controlled asset/parameter selection
- 6 directional views
- Stable rig layer IDs
- Layer visibility + inspector
- Per-layer pivot coordinates
- Parent metadata
- AI Character Director brief parser
- Style, gender, age, body, skin, hair, face, beard, clothing and accessories
- Expressions, hands and poses
- SVG / PNG / JPEG / layered PSD export
- Moho / After Effects Rig Pack ZIP
- Project JSON
- Local project persistence
- Undo / redo

## Rig Pack contract
The ZIP contains:
- `manifest.json`
- `project.json`
- `views/<view>/character.svg`
- `views/<view>/<layer>.svg`
- pivot metadata
- Moho README
- After Effects README

The stable layer IDs are the contract for a future professional asset library.

## AI
The current browser-only AI Director converts natural-language briefs into controlled parameters. It is intentionally provider-neutral. A production deployment can connect `/api/ai/generate` to a server-side model without exposing an API key in the browser.

## Run
`python -m http.server 8080`
Open `http://localhost:8080`.

For a commercial deployment, vendor the CDN dependencies locally and add a server-side AI provider, authentication, cloud project storage and a real owned SVG asset library.
